# General Notes

# When in Doubt…Always Enumerate! Enumeration is the key!

## Resources

- http://www.0daysecurity.com/penetration-testing/enumeration.html
- Backup Link: https://web.archive.org/web/20201122081447/http://www.0daysecurity.com/penetration-testing/enumeration.html
- /usr/share/doc/python-impacket-doc/examples:
- samrdump.py