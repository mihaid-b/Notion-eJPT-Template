# Impacket General Notes

## In Kali

apt install impacket-scripts

## Github

https://github.com/SecureAuthCorp/impacket

## Local Locations:

/usr/share/doc/python3-impacket/examples