# 1. Web

[General Notes](1%20Web%206e9c6/General%20No%20c5a51.md)

[SQL Injection](1%20Web%206e9c6/SQL%20Inject%20fd0e6.md)

[Target _1](1%20Web%206e9c6/Target%20_1%20fb04a.md)