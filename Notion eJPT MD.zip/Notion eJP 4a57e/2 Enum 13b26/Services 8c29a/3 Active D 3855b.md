# 3. Active Directory (AD)

[General Notes](3%20Active%20D%203855b/General%20No%20742ce.md)

[Target _1](3%20Active%20D%203855b/Target%20_1%20563fd.md)