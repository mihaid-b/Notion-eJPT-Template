# 5. High Valuable Info’s

[Hashes](5%20High%20Val%208a506/Hashes%207b21d.md)

[Passwords General Notes](5%20High%20Val%208a506/Passwords%20%2095f6e.md)

[PoC (Prints) Target _1](5%20High%20Val%208a506/PoC%20(Print%2081a08.md)