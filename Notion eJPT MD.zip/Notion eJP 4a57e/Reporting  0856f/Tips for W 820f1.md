# Tips for Writing a Report

1. Understand who is going to be reading this and who is the target audience?
2. The report needs to clear enough that a non-technical person would understand
3. Report should include the following:
    1. Executive Summary
    2. Technical Summary
    3. Detail Report of findings
    4. Recommendations for remediation (If possible)

Resources:

- https://blog.zsec.uk/ltr101-pentest-reporting/
- https://github.com/juliocesarfort/public-pentesting-reports

Public Penetration Testing Reports:

- https://github.com/juliocesarfort/public-pentesting-reports