# Hash types

- cat /etc/login.defs
- grep -A 18 ENCRYPT_METHOD /etc/login.defs
- tail -n 1 /etc/shadow > admin.hash cat admin.hash
- Delete “admin:” and “:18945:0:99999:7:::”