# Wordlists

## Local in Kali:

/usr/share/wordlists

## Other Resources:

Have I been Pwned

- https://haveibeenpwned.com/Passwords

Seclists:

- In Kali: apt install seclists
- Usernames: https://github.com/danielmiessler/SecLists/tree/master/Usernames
- Passwords: https://github.com/danielmiessler/SecLists/tree/master/Passwords

Crackstation’s Dictionary List:

- https://crackstation.net/crackstation-wordlist-password-cracking-dictionary.htm

Rainbow Tables (Rainbow Crack):

- http://project-rainbowcrack.com/table.htm

Rocktastic Mega Wordlist:

- https://labs.nettitude.com/tools/rocktastic/

berzerk0 wordlist:

- https://www.hack3r.com/forum-topic/wikipedia-wordlist

Weakpass:

- https://www.hack3r.com/forum-topic/wikipedia-wordlist

Tools to make your own wordlists:

- Crunch
- Cewl