# 1. Identifying Hash Types

In Kali:

- Hash-identifier

Online:

- Hash Analyzer: https://www.tunnelsup.com/hash-analyzer/