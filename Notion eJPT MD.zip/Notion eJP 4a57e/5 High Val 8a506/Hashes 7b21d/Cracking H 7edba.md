# Cracking Hashes Online

[Hydra](Cracking%20H%207edba/Hydra%200a980.md)

[Medusa](Cracking%20H%207edba/Medusa%20234c7.md)

[NMAP NSE](Cracking%20H%207edba/NMAP%20NSE%20bd51a.md)