# Medusa

- medusa -h target-ip -u [username] -P ../creds/passwords.txt -M http
- medusa -h 172.21.0.0 -U [path to username file] -P [path to password file] -M ftp
- medusa -H hosts.txt -U [path to username file] -P [path to password file] -M http
- medusa -h 172.21.0.0 -U [path to username file] -P [path to password file] -M ssh -n 2222
- medusa -h 172.21.0.0 -U [path to username file] -P [path to password file] -M ftp -O log.txt