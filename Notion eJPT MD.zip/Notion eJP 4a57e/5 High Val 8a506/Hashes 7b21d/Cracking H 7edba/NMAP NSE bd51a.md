# NMAP NSE

nmap -p 22 –script ssh-brute –script-args userdb=/root/users (user list file) $ip