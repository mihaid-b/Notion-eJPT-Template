# Cracking Hashes Offline

[Cracking WEP_WPA_WPA 2 PSK Authetication](Cracking%20H%20fedf5/Cracking%20W%201d00d.md)

[Hash types](Cracking%20H%20fedf5/Hash%20types%2051213.md)

[Hashcat](Cracking%20H%20fedf5/Hashcat%20beea6.md)

[John The Ripper](Cracking%20H%20fedf5/John%20The%20R%20f4e3c.md)

[Wordlists](Cracking%20H%20fedf5/Wordlists%20737f9.md)