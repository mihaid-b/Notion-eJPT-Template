# Hashes

[1. Identifying Hash Types](Hashes%207b21d/1%20Identify%2005a10.md)

[2. Dumping Hashes](Hashes%207b21d/2%20Dumping%20%2007d52.md)

[Cracking Hashes Offline](Hashes%207b21d/Cracking%20H%20fedf5.md)

[Cracking Hashes Online](Hashes%207b21d/Cracking%20H%207edba.md)