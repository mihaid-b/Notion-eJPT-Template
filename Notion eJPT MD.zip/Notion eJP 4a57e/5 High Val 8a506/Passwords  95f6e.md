# Passwords General Notes

# Any passwords that you find should be documented here. Include steps on how you were able to obtain them from your target: