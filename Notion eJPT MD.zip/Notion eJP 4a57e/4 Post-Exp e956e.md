# 4. Post-Exploit

[1. General Notes](4%20Post-Exp%20e956e/1%20General%20%202e251.md)

[2. C2 Frameworks](4%20Post-Exp%20e956e/2%20C2%20Frame%200d673.md)

[BloodHound](4%20Post-Exp%20e956e/BloodHound%204a2fe.md)

[Impacket](4%20Post-Exp%20e956e/Impacket%20c2211.md)

[Mimikatz](4%20Post-Exp%20e956e/Mimikatz%2096637.md)

[Rubeus](4%20Post-Exp%20e956e/Rubeus%2084c6f.md)

[Transferring Files](4%20Post-Exp%20e956e/Transferri%208b898.md)