# Intro

# Try smarter, not harder

1. Check instructions twice, use tools help function.
2. Once you got initial foothold —→  look for /tmp or /opt folders —→ write&execute permissions