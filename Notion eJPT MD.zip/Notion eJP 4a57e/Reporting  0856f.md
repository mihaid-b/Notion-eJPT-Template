# Reporting (Not Needed For Exam)

[OSCP Report Template](Reporting%20%200856f/OSCP%20Repor%209ecd7.md)

[Tips for Writing a Report](Reporting%20%200856f/Tips%20for%20W%20820f1.md)