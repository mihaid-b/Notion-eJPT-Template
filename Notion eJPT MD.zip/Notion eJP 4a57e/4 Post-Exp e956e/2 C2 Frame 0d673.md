# 2. C2 Frameworks

## Empire C2:

Github: https://github.com/BC-SECURITY/Empire

In Kali Linux:

apt install powershell-empire

Install Empire Manually:

1. cd /Empire/setup
2. ./install.sh
- Current Listeners:

(Empire) > listeners [!] No listeners currently active (Empire: listeners) > uselistener dbx http http_com http_foreign http_hop http_mapi meterpreter onedrive redirector

## Covenant

Source: https://github.com/cobbr/Covenant

In Kali Repo:

sudo apt install covenant-kbx

Installing manually on Kali:

1. apt install dotnet-sdk-2.2
2. git clone –recurse-submodules https://github.com/cobbr/Covenant
3. cd Covenant/Covenant
4. dotnet build
5. dotnet run