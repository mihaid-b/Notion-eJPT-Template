# Notion eJPT Template

[Intro](Notion%20eJP%204a57e/Intro%20a86ca.md)

[General Information](Notion%20eJP%204a57e/General%20In%20d733d.md)

[1. Recon](Notion%20eJP%204a57e/1%20Recon%2041552.md)

[2. Enum](Notion%20eJP%204a57e/2%20Enum%2013b26.md)

[ ! Pivoting & Tunneling](Notion%20eJP%204a57e/!%20Pivoting%20cbbbe.md)

[3. Exploiting](Notion%20eJP%204a57e/3%20Exploiti%201b079.md)

[4. Post-Exploit](Notion%20eJP%204a57e/4%20Post-Exp%20e956e.md)

[5. High Valuable Info’s](Notion%20eJP%204a57e/5%20High%20Val%208a506.md)

[Reporting (Not Needed For Exam)](Notion%20eJP%204a57e/Reporting%20%200856f.md)